(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__08df4fs._.css","static/chunks/node_modules_next_dist_0tt2wve._.js"],
    source: "dynamic"
});
